<?php
return [

   'view_replace_str'  =>  [
    '__PUBLIC__'=>SITE_URL.'/static/admin',
    '__IMG__'=>SITE_URL.'/static',
    ],

    'template'               => [
        // 模板后缀
        'view_suffix'  => 'htm',
    ],


    
];
