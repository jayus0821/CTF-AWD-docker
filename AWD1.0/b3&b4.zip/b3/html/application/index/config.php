<?php
return [
   'view_replace_str'  =>  [
    '__PUBLIC__'=>SITE_URL.'/static/index',
    '__IMG__'=>SITE_URL.'/static',
    ],
];
