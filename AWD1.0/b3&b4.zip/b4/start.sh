#!/bin/sh
service ssh restart
